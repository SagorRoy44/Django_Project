from django.contrib import admin
from studentcrud.models import Student
# Register your models here.

admin.site.register(Student)
