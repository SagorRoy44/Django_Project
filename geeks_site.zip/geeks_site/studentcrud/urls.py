from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('add-student/' , views.add_student, name='add-student'),
    path('student-datails/<int:student_id>' , views.student_details, name='student-details'),
    path('delete-student/<int:student_id>' , views.delete_student, name='delete_student'),
]