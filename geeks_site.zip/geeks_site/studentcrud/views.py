from django.shortcuts import render,redirect
from studentcrud.models import Student
from studentcrud.forms import StudentForm


# Create your views here.

def home(request):  
    students = Student.objects.all()
    return render(request, template_name='home.html', context={'students': students})

def add_student(request):
    form= StudentForm()
    if request.method=='POST':
        form=StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    return render(request,template_name='addstudent.html',context={'form':form})

def student_details(request,student_id):
    student = student.object.get(pk=student_id)
    return render(request, template_name='student_details.html',context={'student' : student})

def delete_student(request,student_id):
    if request.method == 'POST':
     student = Student.objects.get(pk=student_id)
     student.delete()
    return redirect('home')

