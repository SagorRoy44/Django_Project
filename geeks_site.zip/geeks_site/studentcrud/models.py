from django.db import models

# Create your models here.
class Student(models.Model):

    DEPARTMENTS=[
        ('ICT','ICT'),
        ('CSE','CSE'),
        ('TEX','TEX'),
        ('ME','ME')
    ]
    id = models.AutoField(primary_key=True)
    name=models.CharField(max_length=50)
    age=models.IntegerField(null=True)
    CGPA=models.FloatField()
    dept = models.CharField(max_length=50,choices=DEPARTMENTS,default='ICT')

    def __str__(self):
        return f"id : {self.id}, name= {self.name}, age={self.age}"
    
